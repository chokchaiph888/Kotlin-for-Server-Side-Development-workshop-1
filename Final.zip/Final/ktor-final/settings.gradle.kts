rootProject.name = "ktor-final"
