package com.example.routes

import io.ktor.application.call
import io.ktor.http.HttpStatusCode
import io.ktor.server.response.respond
import io.ktor.server.routing.Route
import io.ktor.server.routing.get
import io.ktor.server.routing.post
import io.ktor.server.routing.put
import io.ktor.server.routing.delete
import com.example.models.Poll
import com.example.models.PollOption
import com.example.services.PollService
import io.ktor.server.request.receive
import io.ktor.server.routing.route

fun Route.pollRoutes() {
    route("/polls") {
        get {
            val polls = PollService.getAllPolls()
            call.respond(HttpStatusCode.OK, polls)
        }

        post {
            val poll = call.receive<Poll>()
            val createdPoll = PollService.createPoll(poll)
            call.respond(HttpStatusCode.Created, createdPoll)
        }

        delete("{id}") {
            val id = call.parameters["id"]?.toIntOrNull()
            if (id != null) {
                PollService.deletePoll(id)
                call.respond(HttpStatusCode.NoContent)
            } else {
                call.respond(HttpStatusCode.BadRequest, "Invalid Poll ID")
            }
        }
    }

    route("/options/{id}") {
        post("vote") {
            val id = call.parameters["id"]?.toIntOrNull()
            if (id != null) {
                val updatedOption = PollService.vote(id)
                call.respond(HttpStatusCode.OK, updatedOption)
            } else {
                call.respond(HttpStatusCode.BadRequest, "Invalid Poll Option ID")
            }
        }

        put {
            val pollOption = call.receive<PollOption>()
            val updatedOption = PollService.updatePollOption(pollOption)
            call.respond(HttpStatusCode.OK, updatedOption)
        }
    }
}
