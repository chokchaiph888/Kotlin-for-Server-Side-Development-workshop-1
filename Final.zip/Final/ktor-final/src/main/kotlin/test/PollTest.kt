package com.example

import io.ktor.application.*
import io.ktor.server.testing.*
import io.ktor.http.HttpStatusCode
import org.junit.Test
import kotlin.test.assertEquals

class PollTest {

    @Test
    fun testCreatePoll() = testApplication {
        application {
            module()
        }

        val poll = """{"id": 1, "question": "What is your favorite color?"}"""

        val response = client.post("/polls") {
            setBody(poll)
            contentType(io.ktor.http.ContentType.Application.Json)
        }

        assertEquals(HttpStatusCode.Created, response.status)
    }

    @Test
    fun testVote() = testApplication {
        application {
            module()
        }

        val voteRequest = """{}"""

        val response = client.post("/options/1/vote") {
            setBody(voteRequest)
            contentType(io.ktor.http.ContentType.Application.Json)
        }

        assertEquals(HttpStatusCode.OK, response.status)
    }

    @Test
    fun testDeletePoll() = testApplication {
        application {
            module()
        }

        val response = client.delete("/polls/1")
        assertEquals(HttpStatusCode.NoContent, response.status)
    }

    @Test
    fun testUpdatePollOption() = testApplication {
        application {
            module()
        }

        val updatedOption = """{"id": 1, "text": "Red", "voteCount": 10, "pollId": 1}"""

        val response = client.put("/options/1") {
            setBody(updatedOption)
            contentType(io.ktor.http.ContentType.Application.Json)
        }

        assertEquals(HttpStatusCode.OK, response.status)
    }
}
