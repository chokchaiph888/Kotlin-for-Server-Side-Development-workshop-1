package com.example.services

import com.example.models.Poll
import com.example.models.PollOption
import com.example.repositories.PollRepository

object PollService {
    fun getAllPolls(): List<Poll> = PollRepository.getAllPolls()

    fun createPoll(poll: Poll): Poll {
        return PollRepository.createPoll(poll)
    }

    fun vote(id: Int): PollOption {
        return PollRepository.vote(id)
    }

    fun deletePoll(id: Int) {
        PollRepository.deletePoll(id)
    }

    fun updatePollOption(option: PollOption): PollOption {
        return PollRepository.updatePollOption(option)
    }
}
