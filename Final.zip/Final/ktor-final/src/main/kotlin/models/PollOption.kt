package com.example.models

import kotlinx.serialization.Serializable

@Serializable
data class PollOption(
    val id: Int,
    val text: String,
    val voteCount: Int,
    val pollId: Int
)
