package com.example.repositories

import com.example.models.Poll
import com.example.models.PollOption

object PollRepository {
    private val polls = mutableListOf<Poll>()
    private val pollOptions = mutableListOf<PollOption>()

    fun getAllPolls(): List<Poll> = polls

    fun createPoll(poll: Poll): Poll {
        polls.add(poll)
        return poll
    }

    fun vote(id: Int): PollOption {
        val option = pollOptions.find { it.id == id } ?: throw Exception("Option not found")
        val updatedOption = option.copy(voteCount = option.voteCount + 1)
        pollOptions[pollOptions.indexOf(option)] = updatedOption
        return updatedOption
    }

    fun deletePoll(id: Int) {
        polls.removeIf { it.id == id }
    }

    fun updatePollOption(option: PollOption): PollOption {
        val index = pollOptions.indexOfFirst { it.id == option.id }
        if (index != -1) {
            pollOptions[index] = option
            return option
        }
        throw Exception("Poll Option not found")
    }
}
