package com.example

import io.ktor.application.*
import io.ktor.features.ContentNegotiation
import io.ktor.server.engine.embeddedServer
import io.ktor.server.netty.Netty
import io.ktor.server.routing.routing
import io.ktor.server.application.install
import io.ktor.serialization.kotlinx.json
import com.example.routes.pollRoutes

fun Application.module() {
    install(ContentNegotiation) {
        json()
    }

    routing {
        pollRoutes()  // API Routes สำหรับ Poll
    }
}

fun main() {
    embeddedServer(Netty, port = 8080, module = Application::module).start(wait = true)
}
